@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

set "BASE=%~dp0"
set "ADB=%BASE%platform-tools\adb.exe"
set "APK=%BASE%ReEND-Guard-ZFlip5.apk"
set "PKG=com.ojun.reendguard"
set "ACCESS=com.ojun.reendguard/com.ojun.reendguard.MacroAccessibilityService"
set "LISTENER=com.ojun.reendguard/com.ojun.reendguard.NotificationBlockerService"

title RE:END Guard - Z Flip5 자동 설정

echo.
echo ============================================================
echo   RE:END Guard / Z Flip5 자동 설정
echo ============================================================
echo.

if not exist "%ADB%" (
  echo [오류] platform-tools\adb.exe를 찾지 못했습니다.
  echo 압축파일의 폴더 구조를 유지한 채 다시 풀어 주세요.
  goto :fail
)
if not exist "%APK%" (
  echo [오류] ReEND-Guard-ZFlip5.apk를 찾지 못했습니다.
  goto :fail
)

"%ADB%" start-server >nul 2>&1
set "STATE="
for /f "delims=" %%S in ('"%ADB%" get-state 2^>nul') do set "STATE=%%S"
if /I not "!STATE!"=="device" (
  echo [오류] 허용된 Z Flip5를 찾지 못했습니다.
  echo.
  echo 휴대폰에서 다음 두 가지만 먼저 해 주세요.
  echo   1. 개발자 옵션 ^> USB 디버깅 켜기
  echo   2. USB 연결 후 '이 컴퓨터에서 항상 허용' 체크하고 허용
  echo.
  "%ADB%" devices
  goto :fail
)

echo [1/7] 앱 설치 중...
"%ADB%" install -r -g "%APK%" >nul
if errorlevel 1 (
  echo [오류] APK 설치에 실패했습니다. 휴대폰의 설치 확인 화면을 확인해 주세요.
  goto :fail
)

echo [2/7] 제한된 설정 및 백그라운드 실행 허용 중...
"%ADB%" shell appops set %PKG% ACCESS_RESTRICTED_SETTINGS allow >nul 2>&1
"%ADB%" shell appops set %PKG% RUN_IN_BACKGROUND allow >nul 2>&1
"%ADB%" shell appops set %PKG% RUN_ANY_IN_BACKGROUND allow >nul 2>&1

echo [3/7] 접근성 매크로 서비스 켜는 중...
set "CURRENT="
for /f "usebackq delims=" %%S in (`"%ADB%" shell settings get secure enabled_accessibility_services 2^>nul`) do set "CURRENT=%%S"
if not defined CURRENT set "CURRENT=null"
if /I "!CURRENT!"=="null" (
  set "NEW_ACCESS=%ACCESS%"
) else (
  echo(!CURRENT!| findstr /L /C:"%ACCESS%" >nul
  if errorlevel 1 (
    set "NEW_ACCESS=!CURRENT!:%ACCESS%"
  ) else (
    set "NEW_ACCESS=!CURRENT!"
  )
)
"%ADB%" shell settings put secure enabled_accessibility_services "!NEW_ACCESS!" >nul
"%ADB%" shell settings put secure accessibility_enabled 1 >nul

echo [4/7] 알림 접근 권한 켜는 중...
"%ADB%" shell cmd notification allow_listener %LISTENER% >nul 2>&1

echo [5/7] 방해 금지 제어 권한 켜는 중...
"%ADB%" shell cmd notification allow_dnd %PKG% >nul 2>&1

echo [6/7] 배터리 절전 예외 처리 중...
"%ADB%" shell dumpsys deviceidle whitelist +%PKG% >nul 2>&1

echo [7/7] 알림 차단과 Re:END 자동 복귀 활성화 중...
"%ADB%" shell am force-stop %PKG% >nul 2>&1
"%ADB%" shell am start -n %PKG%/.MainActivity --ez auto_setup true >nul 2>&1

ping 127.0.0.1 -n 3 >nul

echo.
echo ============================================================
echo   설정 완료
echo ============================================================
echo.
echo 휴대폰에서 RE:END Guard가 열렸습니다.
echo 이제 '한 사이클 녹화'를 눌러 평소 동작을 한 번만 수행하고,
echo 화면 위 '완료'를 누른 뒤 '매크로 실행'을 누르세요.
echo.
echo 긴급 중지: 화면 오른쪽 위 '중지' 또는 볼륨 내리기 두 번
echo.
pause
exit /b 0

:fail
echo.
echo 설정을 완료하지 못했습니다.
pause
exit /b 1
