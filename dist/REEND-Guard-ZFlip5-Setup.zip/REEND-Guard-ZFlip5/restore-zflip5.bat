@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

set "BASE=%~dp0"
set "ADB=%BASE%platform-tools\adb.exe"
set "PKG=com.ojun.reendguard"
set "ACCESS=com.ojun.reendguard/com.ojun.reendguard.MacroAccessibilityService"
set "LISTENER=com.ojun.reendguard/com.ojun.reendguard.NotificationBlockerService"

title RE:END Guard - 설정 원상복구

echo.
echo ============================================================
echo   RE:END Guard 설정 원상복구
echo ============================================================
echo.

if not exist "%ADB%" (
  echo [오류] platform-tools\adb.exe를 찾지 못했습니다.
  goto :fail
)

"%ADB%" start-server >nul 2>&1
set "STATE="
for /f "delims=" %%S in ('"%ADB%" get-state 2^>nul') do set "STATE=%%S"
if /I not "!STATE!"=="device" (
  echo [오류] USB 디버깅이 허용된 휴대폰을 찾지 못했습니다.
  "%ADB%" devices
  goto :fail
)

echo [1/5] 매크로 중지 및 이전 방해 금지 설정 복원 중...
"%ADB%" shell am start -n %PKG%/.MainActivity --ez disable_all true >nul 2>&1
ping 127.0.0.1 -n 3 >nul

echo [2/5] 알림 권한 해제 중...
"%ADB%" shell cmd notification disallow_listener %LISTENER% >nul 2>&1
"%ADB%" shell cmd notification disallow_dnd %PKG% >nul 2>&1

echo [3/5] 접근성 서비스 목록에서 제거 중...
set "CURRENT="
for /f "usebackq delims=" %%S in (`"%ADB%" shell settings get secure enabled_accessibility_services 2^>nul`) do set "CURRENT=%%S"
if not defined CURRENT set "CURRENT=null"
set "NEW_ACCESS=!CURRENT!"
if /I not "!CURRENT!"=="null" (
  if /I "!CURRENT!"=="%ACCESS%" (
    set "NEW_ACCESS="
  ) else (
    set "NEW_ACCESS=!NEW_ACCESS:%ACCESS%:=!"
    set "NEW_ACCESS=!NEW_ACCESS::%ACCESS%=!"
    set "NEW_ACCESS=!NEW_ACCESS:%ACCESS%=!"
  )
)
"%ADB%" shell settings put secure enabled_accessibility_services "!NEW_ACCESS!" >nul
if not defined NEW_ACCESS (
  "%ADB%" shell settings put secure accessibility_enabled 0 >nul
)

echo [4/5] 배터리 절전 예외 해제 중...
"%ADB%" shell dumpsys deviceidle whitelist -%PKG% >nul 2>&1
"%ADB%" shell appops set %PKG% RUN_IN_BACKGROUND default >nul 2>&1
"%ADB%" shell appops set %PKG% RUN_ANY_IN_BACKGROUND default >nul 2>&1
"%ADB%" shell appops set %PKG% ACCESS_RESTRICTED_SETTINGS default >nul 2>&1

echo [5/5] 완료 확인 중...
"%ADB%" shell am force-stop %PKG% >nul 2>&1

echo.
echo 원상복구가 끝났습니다. 앱은 삭제하지 않고 비활성 상태로 남겨뒀습니다.
echo 앱까지 지우려면 Windows 명령 프롬프트에서 아래 명령을 실행하세요.
echo   platform-tools\adb.exe uninstall %PKG%
echo.
pause
exit /b 0

:fail
echo.
echo 원상복구를 완료하지 못했습니다.
pause
exit /b 1
